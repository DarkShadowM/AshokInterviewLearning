package DSA.heaps;

public class HeapOperations {

    public static void main(String[] args) {
        MaxHeap maxHeap = new MaxHeap();
        maxHeap.push(17);
        maxHeap.push(6);
        maxHeap.push(5);
        maxHeap.push(7);
        maxHeap.push(8);
        maxHeap.push(21);
        maxHeap.push(22);

    }

}
