package core_java_only.java8;

public class Order {}
